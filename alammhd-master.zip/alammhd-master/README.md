pkg update

pkg upgrade

pkg install php

pkg install curl

pkg install git

git clone https://github.com/ipanxcool/alammhd

cd alammhd

php claim.php


Biar lebih jelas bisa di lihat di 
https://youtu.be/Emj9i3Q5J90
